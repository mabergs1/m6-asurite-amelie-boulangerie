# m6-asurite-amelie-boulangerie
Starter files for the Module 6 images, favicons, and meta description tag activity for GIT215
